﻿{
	"version": 1725603809,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/image-sheet0.png",
		"images/image2-sheet0.png",
		"images/image5-sheet0.png",
		"images/image8-sheet0.png",
		"images/image9-sheet0.png",
		"images/image10-sheet0.png",
		"images/screenshot_20240906_083059removebgpreview-sheet0.png",
		"images/image3-sheet0.png",
		"images/ledakan.png",
		"images/particles.png",
		"images/tiledbackground.png",
		"images/tiledbackground2.png",
		"media/jump scare - sound effect.ogg",
		"media/squeaky-jumpscare-2-102254.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}